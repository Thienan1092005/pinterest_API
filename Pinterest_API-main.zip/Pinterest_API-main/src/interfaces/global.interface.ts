export interface ResponseType {
  message: string;
  data: any;
  statusCode: number;
  date: Date;
}
